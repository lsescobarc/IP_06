﻿using System.Xml.Serialization;
class Program
{
    static void main(string[]args)
    {
        Console.WriteLine("ingrese su nombre ");
        string Nombre = Console.ReadLine();
        Console.WriteLine("Hola mundo");
        Console.WriteLine("soy"+Nombre);
        /*
         Esto es un ejemplo de comentarios
        */
        // otros comentario 

        Console.WriteLine("Hola mundo");
        Console.WriteLine("soy"+Nombre);

        Console.ReadKey();
    }
 
}
