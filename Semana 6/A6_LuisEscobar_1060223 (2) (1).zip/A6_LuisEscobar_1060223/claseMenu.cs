﻿class ClaseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi progarana,revision de fallos en maquinaria0");
        Console.WriteLine();
        Console.WriteLine("seleccione un tipo de maquina");
        Console.WriteLine("Menu principal");
        Console.WriteLine();
        Console.WriteLine("1.Maquina de soplado");
        Console.WriteLine("2.Maquina de llenado de botellas");
        Console.WriteLine("3.Maquina de etiquetas");
        Console.WriteLine("4.Maquina de envoltura");
        string seleccionmenu;
        seleccionmenu = Console.ReadLine();
        Console.WriteLine();
        switch (seleccionmenu)
        {
            case "1":
                Console.WriteLine("Ud selecciono opcion:" + seleccionmenu + "Maquina de soplado");
                break;
            case "2":
                Console.WriteLine("Ud selecciono opcion:" + seleccionmenu + "Maquina de llenado de botellas");
                break;
            case "3":
                Console.WriteLine("Ud selecciono opcion:" + seleccionmenu + "Maquina de etiquetas");
                break;
            case "4":
                Console.WriteLine("Ud selecciono opcion:" + seleccionmenu + "Maquina de envoltura");
                break;

            default:
                Console.WriteLine("seleccione una opcion valida");
                break;
        }
        Console.ReadKey();
    }
   
}
