﻿using System.Timers;

namespace L7_Luis_Escobar_1060223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");
            int numero1 = 0;


            Console.WriteLine("ingrese un numero");
            numero1 = Int32.Parse(Console.ReadLine());

            if (numero1 > 0)
            {
                Console.WriteLine("el numero es positivo");
            }
            else if (numero1 < 0)
            {
                Console.WriteLine("el numero es negativo");

            }
            else
            {
                Console.WriteLine("el numero es igual a  0 ");
            }
            Console.ReadKey();
            Console.Clear();
            // segundo ejercicio 
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("ingrese un numero de dia");

            string semana;
            semana = Console.ReadLine();
            switch(semana)
            {
                case "1":
                    Console.WriteLine("Dia: lunes");
                    break;
                case "2":
                    Console.WriteLine("Dia : martes");
                    break;
                case "3":
                    Console.WriteLine("Dia : miercoles ");
                    break;
                case "4":
                    Console.WriteLine("Dia : jueves");
                    break;
                case "5":
                    Console.WriteLine("Dia : viernes");
                    break;
                case "6":
                    Console.WriteLine("Dia : sabado");
                    break;
                case "7":
                    Console.WriteLine("Dia : domingo");
                    break;
                default:
                    Console.WriteLine("error el numero ingresado no es valido ");
                    break;
            }

            Console.ReadKey();
           

        }   
    }
}