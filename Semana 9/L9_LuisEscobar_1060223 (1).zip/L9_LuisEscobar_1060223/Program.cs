﻿using System.Threading;

namespace L9_LuisEscobar_1060223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("EJERCICIO 1");
            Console.WriteLine("BIENVENIDO");
            double Monto = 0;
            double descuento= 0;

            Console.WriteLine("ingrese el valor de monto ");
            if (double.TryParse(Console.ReadLine(), out Monto)) ;
            {
                if (Monto < 400)

                {
                    Console.WriteLine("el monto ingresado no cuenta con descuento ");
                }
                else if (Monto <= 1000)
                {
                    descuento = 0.07;
                }
                else if (Monto <= 5000)
                {
                    descuento = 0.10;
                }
                else if (Monto <= 15000)
                {
                    descuento = 0.15;
                }
                else if (Monto > 15000)
                {
                    descuento = 0.25;
                }
                Console.WriteLine("el usuario posee codigo de descuento si/no");
                string tienecodigo = Console.ReadLine();
                if (tienecodigo == "si")
                {
                    descuento += 0.05;
                }
                else
                {
                    Console.WriteLine("Error ingresar un monto valido ");  
                }

            }
                double montoFinal = Monto - (Monto * descuento);
                Console.WriteLine($"El monto a pagar después del descuento es: Q{montoFinal}");

             
            }


            
        }
                 
       

    }



    
