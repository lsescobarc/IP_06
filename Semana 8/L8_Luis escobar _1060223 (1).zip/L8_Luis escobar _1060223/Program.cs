﻿namespace L8_Luis_santiago_1060223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Vo = 0.0;
            double Vf = 0.0;
            double a = 0.0;
            double t = 0.0;

            Console.WriteLine("Ejercicio numero 1 determinar las diferentes variables  ");
            Console.WriteLine("Para la formula Vf= Vo + at ");
            Console.WriteLine("ingrese la velocidad inicial ");
            Vo = double.Parse(Console.ReadLine());
            Console.WriteLine("ingrese la velocidad final");
            Vf = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la aceleracion");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("ingrese su tiempo");
            t = double.Parse(Console.ReadLine());

            if (Vf == 0.00 && Vo == 0.00 && a == 0.00 && t == 0.00)
            {
                Console.WriteLine(" ingresar un valor correcto ");

            }

            else

            {
                if (Vo == 0.0 && Vf > 0.0 && a > 0.0 && t > 0.0)
                {
                    Vo = Vf - (a * t);
                    Console.WriteLine("La velocidad Inicial " + Vo);
                }

                if (Vf == 0.0 && Vo > 0.0 && a > 0.0 && t > 0.0)
                {
                    Vf = Vo + (a * t);
                    Console.WriteLine(" LA VELOCIDAD FINAL ES: " + Vf);
                }
                if (Vf > 0.0 && Vo > 0.0 && a == 0.0 && t > 0.0)
                {
                    a = (Vf - Vo) / t;
                    Console.WriteLine(" LA VELOCIDAD FINAL ES: " + a);

                }
                if (Vf > 0.0 && Vo > 0.0 && a > 0.0 && t == 0.0)
                {
                    t = (Vf - Vo) / a;
                    Console.WriteLine(" LA VELOCIDAD FINAL ES: " + t);
                }
            }
            Console.ReadLine();




        }
    }

}