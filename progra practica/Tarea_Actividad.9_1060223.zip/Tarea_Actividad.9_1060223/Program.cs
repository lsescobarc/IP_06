﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

class progam
{
    static void Main(string[] args)
    {
        Console.WriteLine("Bienvenido");

        int nunero1 = 0;
        int nunero2 = 0;
        int SUMA = 0;
        int Multiplicacion = 0;

        Console.WriteLine("ingrese un numero");
        Console.WriteLine();
        nunero1 = Int32.Parse(Console.ReadLine());
        Console.WriteLine("ingrese un numero");
        Console.WriteLine();
        nunero2 = Int32.Parse(Console.ReadLine());
        SUMA = nunero1 + nunero2;
        Multiplicacion = nunero1 * nunero2;
        Console.WriteLine("el resultado de la suma numero1 y numero 2:" + SUMA);
        Console.WriteLine();
        Console.WriteLine("el resultado de la multipliacion numero1 y numero2:" + Multiplicacion);
       
        if (nunero1 > 5)
        {
            Console.WriteLine(" El primer numero ingresado es mayor a 5 ");
        }
        else
        {
            Console.WriteLine(" El primer numero ingresado es menor a 5 ");
        }

        if (SUMA > 5)
        {
            Console.WriteLine(" La suma es mayor a 5 ");
        }
        else
        {
            Console.WriteLine(" La suma es menor a 5");
        }
    }

}
